const tabsEl = document.querySelector('#tabs');

new Tabs(tabsEl);